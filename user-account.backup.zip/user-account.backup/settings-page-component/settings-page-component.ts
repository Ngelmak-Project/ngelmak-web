import { Component } from '@angular/core';

@Component({
  selector: 'app-settings-page-component',
  imports: [],
  templateUrl: './settings-page-component.html',
})
export class SettingsPageComponent {

}
