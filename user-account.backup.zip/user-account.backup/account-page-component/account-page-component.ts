import { Component } from '@angular/core';

@Component({
  selector: 'app-account-page-component',
  imports: [],
  templateUrl: './account-page-component.html',
})
export class AccountPageComponent {

}
