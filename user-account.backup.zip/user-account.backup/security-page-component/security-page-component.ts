import { Component } from '@angular/core';

@Component({
  selector: 'app-security-page-component',
  imports: [],
  templateUrl: './security-page-component.html',
})
export class SecurityPageComponent {

}
